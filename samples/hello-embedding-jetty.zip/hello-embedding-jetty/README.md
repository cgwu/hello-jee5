参考网址:
http://wiki.eclipse.org/Jetty/Tutorial/Embedding_Jetty
